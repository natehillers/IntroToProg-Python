# -------------------------------------------------#
# Title: Creating classes and functions
#
# Name: Nathaniel Hillers
# Date:  12 May 2017
# ChangeLog:
#   ver 1.0: 12 May 2017: finished
#
# # -------------------------------------------------#

##---import os library---##
import os

##---empty dict/list variables---##
todolist = []
tododict = {}


class filemanipulation(object):
    @staticmethod
    def createtodofile():
        '''
        This function will write/create your todo.txt file so it doesn't need to be created by hand before running the program.
        Keep in mind, due to opening it as 'w', if you use the code, it will overwrite the file each time you run this program.
        '''
        newfile = open(os.path.abspath("todo.txt"), "w")
        newfileline = "Clean House,low\nPay Bills,high"
        newfile.write(newfileline)
        newfile.close()


filemanipulation.createtodofile()
# comment out the line above this line to NOT run the createtodofile function and keep original file

##---Open the file for reading and manipulating---##
todofile = open(os.path.abspath("todo.txt"), "r")


class reformatting(object):
    @staticmethod
    def maketododict():
        '''
        For every line in the file, iterate over to make a dictionary out of every other value
        '''
        for line in todofile:
            line = line.strip()
            key, value = line.split(",")
            tododict[key] = value

    @staticmethod
    def maketodolist():
        '''
        This function will iterate over every key and value in the dictionary to create a list
        '''
        for key, value in tododict.items():
            newline = [key, value]
            todolist.append(newline)


##---Make todo dictionary ---##
reformatting.maketododict()

##---Close the file---##
todofile.close()

##---Make todo list---##
reformatting.maketodolist()


class menufunctions(object):
    ##---Interior menu funtions---##
    @staticmethod
    def displist():
        print(todolist)

    @staticmethod
    def additems():
        '''
        This will add items to the already created todo list
        It will first need to create a temporary list that will be appended to the original master list
        '''
        print("Okay lets add some items! Start by typing the to-do 'item', then type the priority ")
        newtodoitem = input('To-do item to add: ')
        newtodopriority = input('New to-do item priority: ')
        newtodolist = [newtodoitem, newtodopriority]
        todolist.append(newtodolist)
        print("Updated list:\n" + str(todolist))

    @staticmethod
    def delitems():
        '''
        This function will remove items from the todo master list. It does so by asking the user for an index to reference.
        '''
        print("Here are the current items, choose one to delete:")
        print(todolist)
        userdelete = int(input(
            "Type the index of the item you would like to delete. Don't forget the first 'item' is at index 0! "))
        print("Deleting item with index: " + str(userdelete))
        del todolist[userdelete]
        print("Updated list:\n" + str(todolist))

    @staticmethod
    def savefile():
        '''
        This will save the current master list to a file in the same directory as this python script
        '''
        print("Saving data to 'todo' file...")
        todofile = open(os.path.abspath("todo.txt"), "w")
        for dimension in todolist:
            todofile.write(str(dimension) + '\n')

    ##---Main menu: defined as 'mainmenu'---##
    @staticmethod
    def mainmenu():
        '''
        This is the main menu function. It runs mainly on the defined functions above as well as some one-off code inside.
        '''
        while (True):
            userselect = 0
            print(
                "\n****Add-Remove menu****\nSelect '1' to display current items\nSelect '2' to add items\nSelect '3' to delete items\nSelect '4' to save all current items to file\nSelect '0' exit menu and quit")
            userselect = int(input("\nWhat is your selection? "))
            if userselect == 1:
                menufunctions.displist()
            elif userselect == 2:
                menufunctions.additems()
            elif userselect == 3:
                menufunctions.delitems()
            elif userselect == 4:
                menufunctions.savefile()
            elif userselect == 0:
                print("The menu will now exit, unsaved changes will be lost.")
                todofile.close()
                break
            else:
                print("Please select '1', '2', '3', '4', or '0'")
                continue


##---Run the menu program---##
menufunctions.mainmenu()
