'''
### This small block of code at the beginning will write/create your 'todo.txt' file so it doesn't need to be created before running the program.
### Keep in mind, due to opening it as 'w', if you use the code, it will overwrite the file each time you run this program.

##---Create the todo.txt file so it doesn't need to be there before starting---##
newfile = open("c:\\_PythonClass\\Module05\\Assignment5\\todo.txt","w")
newfileline = "Clean House,low\nPay Bills,high"
newfile.write(newfileline)
newfile.close()
'''

##---Open the file for reading and manipulating---##
todofile = open("c:\\_PythonClass\\Module05\\Assignment5\\todo.txt","r+")

##---For every line in the file, iterate over to make a dictionary out of every other value---##
tododict = {}
for line in todofile:
    line = line.strip()
    key, value = line.split(",")
    tododict[key] = value
# print(tododict)

##---Iterate over every key and value in the dictionary to create a list---##
todolist = []
for key, value in tododict.items():
    newline = [key, value]
    todolist.append(newline)
# print(todolist)

##---define 'todomenu', a program that creates a menu for user inputs---##
def todomenu():
    while(True):
        userselect = 0
        print("\n****Add-Remove menu****\nSelect '1' to display current items\nSelect '2' to add items\nSelect '3' to delete items\nSelect '4' to save all current items to file\nSelect '0' exit menu and quit")
        userselect = int(input("\nWhat is your selection? "))
        if userselect == 1:
            print(todolist)
        elif userselect == 2:
            print("Okay lets add some items! Start by typing the to-do 'item', then type the priority ")
            newtodoitem = input('To-do item to add: ')
            newtodopriority = input('New to-do item priority: ')
            newtodolist = [newtodoitem, newtodopriority]
            todolist.append(newtodolist)
            print("Updated list:\n" + str(todolist))
        elif userselect == 3:
            print("Here are the current items, choose one to delete:")
            print(todolist)
            userdelete = int(input("Type the index of the item you would like to delete. Don't forget the first 'item' is at index 0! "))
            print("Deleting item with index: " + str(userdelete))
            del todolist[userdelete]
            print("Updated list:\n" + str(todolist))
        elif userselect == 4:
            print("Saving data to 'todo' file...")
            todofile.write(str(todolist))
        elif userselect == 0:
            print("The menu will now exit, unsaved changes will be lost.")
            break
        else:
            print("Please select '1', '2', '3', '4', or '0'")
            continue

##---Run the menu program---##
todomenu()

##---Close the file---##
todofile.close()